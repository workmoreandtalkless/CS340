
public class Clock extends Thread{
	public static long time = System.currentTimeMillis();
	public volatile static boolean inSession =false;
	public static volatile int session=0;
	public static volatile boolean end=false;
	public Clock() {
		setName("Clock");
	}
	
	public void run() {
		for(session =0;session<4;session++) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			inSession = true;
			msg("Movie is in #"+(session+1)+" session.");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {}
			inSession=false;
			Main.speaker.interrupt();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {}
		}
		if(Main.speaker.isAlive())
			Main.speaker.interrupt();
	}
	public void msg(String m) { 
		System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+": "+m);
	}
}
