import java.util.Comparator;
import java.util.Iterator;

public class Speaker extends Thread{
	public static long time = System.currentTimeMillis();
	public static volatile boolean readyForTicket=false;
	public Speaker() {
		setName("Speaker");
	}
	
	public void run() {
		while(!Clock.end) {
			readyForTicket=false;
			try {
				Thread.sleep(500000);
			} catch (InterruptedException e) {
				if(Clock.session==4) break;
				msg("End of the movie");
			}
			Iterator<Visitor> itr=Visitor.inTheater.iterator();
			while(itr.hasNext()) {
				Visitor visitor=itr.next();
				visitor.interrupt();
			}
			Visitor.inTheater.sort((v1,v2)->v1.id>v2.id?-1:1);
			while(Visitor.group.size()!=Visitor.inTheater.size()) {}
			int size= Visitor.group.size();
			for(int i=0;i<size;++i) {
				Visitor visitor = Visitor.group.get(i);
				visitor.groupNo=i/Main.PARTY_TICKET+1;
				visitor.getTicket=true;
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
		msg("end of the day");
	}
	
	public void msg(String m) { 
		System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+": "+m);
	}
}
