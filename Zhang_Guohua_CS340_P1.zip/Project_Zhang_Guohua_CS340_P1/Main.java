
public class Main {
	
	public final static int THERTERCAPACITY = 5;
	public final static int PARTY_TICKET=3;
	
	public static int numVisitors=23;
	public static Visitor[] visitors= new Visitor[numVisitors];
	public static Clock clock = new Clock();
	public static Speaker speaker = new Speaker();
	
	public static void main(String [] args) {
		System.out.println("Story starts");
		clock.start();
		speaker.start();
		for(int i =0;i<numVisitors;i++) {
			visitors[i]=new Visitor(i);
			visitors[i].start();
		}
		
	}
}
