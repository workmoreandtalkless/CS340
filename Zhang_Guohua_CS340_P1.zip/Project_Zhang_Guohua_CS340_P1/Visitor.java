import java.util.Random;
import java.util.Vector;

public class Visitor extends Thread{
	public static long time = System.currentTimeMillis();
	public static volatile Vector<Visitor> inTheater = new Vector<>();
	public volatile boolean triedFindSeat=false;
	public static volatile Vector<Visitor> group = new Vector<>();
	public volatile boolean getTicket=false;
	public int groupNo=0;
	public int id;
	public static Random rand =new Random();
	
	public Visitor(int id) {
		setName("Visitor-" + id);
		this.id=id;
	}
	
	public void run() {
		msg("coming to lobby");
		while(!findSeat()) {
			if(Clock.end) {
				msg("didn't see movie, leave theater");
				return;
			}
		}
		try {
			Thread.sleep(5000000);
		} catch (InterruptedException e) {
			msg("wake up");
		}
		gatherGroup();
		try {
			Thread.sleep(rand.nextInt(2000)+1000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		leave();
	}
	public void leave() {
		int index= inTheater.indexOf(this);
		if(index!=Main.THERTERCAPACITY-1) {
			try {
				Visitor v =inTheater.get(index+1);
				if(v.isAlive())
					v.join();
			} catch (InterruptedException e) {}
		}
		msg("leave the theater.");
		if(index==0) {
			inTheater.clear();
			group.clear();
			if(Clock.session==3) Clock.end=true;
			for(int j=0;j<Main.numVisitors;++j) {
				Main.visitors[j].triedFindSeat=false;
			}
			
		}
	}
	public void gatherGroup() {
		group.add(this);
		msg("waiting for ticket.");
		while(!getTicket) {}
		msg("Get ticket in group#"+groupNo);
	}
	public boolean findSeat() {
		if(Clock.end) return false;
		while(Clock.inSession||triedFindSeat) {}
		if(Clock.end) return false;
		setPriority(10);
		msg("coming into theater");
		if(inTheater.size()==Main.THERTERCAPACITY) {
			msg("cannot find a seat, leaving theater.");
			triedFindSeat=true;
			setPriority(5);
			return false;
		}
		inTheater.add(this);
		msg("find seat");
		setPriority(5);
		return true;
	}
	
	public void msg(String m) { 
		System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+": "+m);
	}
}
